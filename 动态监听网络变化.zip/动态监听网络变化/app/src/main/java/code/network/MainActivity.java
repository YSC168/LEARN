package code.network;

import android.app.*;
import android.os.*;
import android.content.IntentFilter;

public class MainActivity extends Activity 
{

	/*
	 *
	 *Title:地理位置获取
	 *Author:睡客
	 *ps:欢迎加入AIDE交流群，群号码：471542521
	 *ps2:不定时更新代码
	 */

	
	
	
	
	private IntentFilter intentFilter;

	private NetWorkChange networkchange;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
   	intentFilter=new IntentFilter();
		intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
		networkchange=new NetWorkChange(MainActivity.this);
		//注册
		registerReceiver(networkchange,intentFilter);
	}

	@Override
	protected void onDestroy()
	{
		// 程序关闭时取消注册
		super.onDestroy();
		unregisterReceiver(networkchange);
	}
		
		
		
		
}
