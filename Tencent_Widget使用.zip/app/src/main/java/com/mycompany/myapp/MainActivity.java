package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.view.View.*;

import com.tencentqq.widget.QQDialog;
import com.tencentqq.widget.MenuDialog;
import com.tencentqq.widget.MenuDialog.OnSheetItemClickListener;
import com.tencentqq.widget.MenuDialog.setTextColor;
import com.tencentqq.widget.QQToast;
import com.tencentqq.widget.QQToast.setColor;
import com.tencentqq.widget.QQProgress;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Button btn1 = (Button) findViewById(R.id.mainButton1);
		Button btn2 = (Button) findViewById(R.id.mainButton2);
		Button btn3 = (Button) findViewById(R.id.mainButton3);
		Button btn4 = (Button) findViewById(R.id.mainButton4);
		
		btn1.setOnClickListener(new OnClickListener() {
			
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					final QQDialog dialog = new QQDialog(MainActivity.this,R.style.dialog_qq_animation);
					dialog.setViewLine(0xff00B4FF);
					dialog.setTitle("标题");
					dialog.setMessage("消息");
					dialog.setCanceledOnTouchOutside(true);
					dialog.setCancelable(true);
					dialog.setPositiveButton("确定", new OnClickListener(){

							@Override
							public void onClick(View p1)
							{
								// TODO: Implement this method
								dialog.dismiss();
							}
						});
					dialog.show();
				}
			});
			
		btn2.setOnClickListener(new OnClickListener() {
			
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					QQToast.makeText(MainActivity.this,"无聊无聊无聊");
				}
			});
			
		btn3.setOnClickListener(new OnClickListener() {
			
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					QQProgress.showPorgressBar(MainActivity.this,0x95000000,"哈哈哈哈");
				}
			});
			
		btn4.setOnClickListener(new OnClickListener() {
			
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					MenuDialog dialog=new MenuDialog(MainActivity.this,R.style.actionsheet_qq_animation);
					dialog.setCanceledOnTouchOutside(true);
					dialog.setTitle("标题",null);
					dialog.setButton("关闭",setTextColor.BLACK);
					dialog.addItem("这是一", setTextColor.BLACK, new OnSheetItemClickListener() {
							@Override
							public void onClick(int which)
							{
								// TODO: Implement this method
							}
						});
					dialog.addItem("这是二", setTextColor.BLACK, new OnSheetItemClickListener() {
							@Override
							public void onClick(int which)
							{
								// TODO: Implement this method
							}
						});
					dialog.addItem("这是三", setTextColor.BLACK, new OnSheetItemClickListener() {
							@Override
							public void onClick(int which)
							{
								// TODO: Implement this method
							}
						});
					dialog.addItem("这是四", setTextColor.BLACK, new OnSheetItemClickListener() {
							@Override
							public void onClick(int which)
							{
								// TODO: Implement this method
							}
						});
					dialog.show();
				}
			});
		}
    }
