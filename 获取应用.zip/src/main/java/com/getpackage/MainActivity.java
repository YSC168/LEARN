package com.getpackage;

import android.app.*;
import android.os.*;
import android.widget.ListView;
import android.content.pm.PackageManager;
import java.util.List;
import android.content.pm.ApplicationInfo;
import java.util.ArrayList;
import android.content.pm.*;
import java.util.*;
import android.widget.AdapterView.*;
import android.widget.*;
import android.view.*;
import android.graphics.drawable.*;
import java.io.*;
import java.text.*;

public class MainActivity extends Activity implements OnItemClickListener
{

	private ListView mListView;
	private PackageManager pm;
	private ArrayList<ApplicationInfo> applist;//全部应用
	private ArrayList<ApplicationInfo> applists;//安装的应用
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		pm = getPackageManager();
		mListView = (ListView)findViewById(R.id.listview);
		mListView.setOnItemClickListener(this);
		applist = (ArrayList<ApplicationInfo>) pm.getInstalledApplications(ApplicationInfo.FLAG_UPDATED_SYSTEM_APP);
		//排序
		Collections.sort(applist,new ApplicationInfo.DisplayNameComparator(pm));
		applists = new ArrayList<ApplicationInfo>();
		getapp();
		//适配器
		MyAdapter adapter = new MyAdapter(this,applists);
		mListView.setAdapter(adapter);
		adapter.notifyDataSetChanged();
    }

	private void getapp()
	{
		for(ApplicationInfo app : applist){
			if((app.flags & ApplicationInfo.FLAG_SYSTEM) <= 0){
				applists.add(app);
			}else if ((app.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0){
				applists.add(app);
			}
		}
	}
	@Override
	public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
	{
		popwindow(p3);
	}

	private void popwindow(int p1)
	{
		ViewGroup pop = (ViewGroup)getLayoutInflater().inflate(R.layout.pop,null);
		ImageView icon = (ImageView) pop.findViewById(R.id.pop_app_icon);
		TextView packagename = (TextView) pop.findViewById(R.id.pop_packagename);
		TextView appname = (TextView) pop.findViewById(R.id.pop_appname);
		TextView file = (TextView) pop.findViewById(R.id.pop_File);
		TextView size = (TextView) pop.findViewById(R.id.pop_size);
		
		ApplicationInfo p = applists.get(p1);
		packagename.setText("包名:"+p.packageName);
		appname.setText(p.loadLabel(pm));
		file.setText("包装包地址:"+p.sourceDir);
		float si=(float)new File(p.sourceDir).length()/1024/1024;
		DecimalFormat form= new DecimalFormat("##0.00");
		
		size.setText("大小:"+form.format(si)+"MB");
		icon.setImageDrawable(p.loadIcon(pm));
		PopupWindow popupWindow = new PopupWindow(pop, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		//获取焦点
		popupWindow.setFocusable(true);
		ColorDrawable dw = new ColorDrawable(0xb0000000);
		popupWindow.setBackgroundDrawable(dw);
		View view = (View) mListView.getParent();
		popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
		
	}
}
