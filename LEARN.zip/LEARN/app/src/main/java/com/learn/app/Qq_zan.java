package com.learn.app;



import android.accessibilityservice.AccessibilityService;
import android.app.Instrumentation;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.lang.ref.PhantomReference;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import android.util.*;
import android.widget.*;



public class Qq_zan extends AccessibilityService {
    private boolean isFresh=false;
    private String LAUNCHER1 = "com.tencent.mobileqq.activity.VisitorsActivity";
    private String LAUNCHER2 = "com.tencent.mobileqq.activity.FriendProfileCardActivity";
    private String LAUNCHER3 = "com.tencent.mobileqq.nearby.profilecard.NearbyPeopleProfileActivity";
    private boolean isPage1 = false;
    private boolean isPage2=false;
    private boolean isBack = false;
    private AccessibilityNodeInfo Source;
    private boolean isVisitor = false;
    @Override
    public void onAccessibilityEvent(final AccessibilityEvent event) {
        String classname = event.getClassName().toString();
        SharedPreferences settingPreferences= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        boolean isScoll=settingPreferences.getBoolean("scoll_",true);
        isBack = settingPreferences.getBoolean("back_", false);
        if (classname.equals(LAUNCHER1)) {
            isVisitor = true;
            QQ_do();
            if(isScoll){
				Source=event.getSource();
				Scoll_Page();}
        } else {
            isVisitor = false;
        }


        if (classname.equals(LAUNCHER2)) {
            isPage1 = true;
            zan();
        } else {
            isPage1 = false;
        }
//        if (classname.equals(LAUNCHER3)) {
//            isPage2 = true;
//            near_zan();
//        } else {
//            isPage2 = false;
//        }
    }
    public void QQ_do() {
        new Thread(new Runnable() {
				@Override
				public void run() {
					if (isVisitor) {
						AccessibilityNodeInfo nodeinfo = getRootInActiveWindow();
						List<AccessibilityNodeInfo> nodes = nodeinfo.findAccessibilityNodeInfosByText("赞");
						for (int a = 0; a < nodes.size(); a++) {
							if(a==nodes.size()-1){
								if(!isFresh) {
									nodes = nodeinfo.findAccessibilityNodeInfosByText("赞");
								}
								a=0;
							}
							for (int i = 0; i < 10; i++) {
								if (!nodes.isEmpty() &&isVisitor) {
									nodes.get(a).performAction(AccessibilityNodeInfo.ACTION_CLICK);

								}
							}
							//点击显示更多
							List<AccessibilityNodeInfo> more = nodeinfo.findAccessibilityNodeInfosByText("显示更多");
							for (int j = 0; j < more.size(); j++) {
								more.get(j).getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
							}

						}
                    }

				}
			}).start();
    }
	public void Scoll_Page(){
		//滑动界面
		new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						while(isVisitor){
							Thread.sleep(5000);
							//滑动界面
							AccessibilityNodeInfo listNode=Source.getChild(3);
							if(isVisitor&&listNode!=null) {
								listNode.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);}}
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}).start();
	}
//主页赞
	public void zan() {
		new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					if (isPage1) {
						AccessibilityNodeInfo accessibilityEvent = getRootInActiveWindow();
						List<AccessibilityNodeInfo> nodeInfos = accessibilityEvent.findAccessibilityNodeInfosByText("赞");
						for (int a = 0; a < nodeInfos.size(); a++) {
							for (int i = 0; i < 20; i++) {
								nodeInfos.get(a).performAction(AccessibilityNodeInfo.ACTION_CLICK);
								if (i == 19) do_back();
							}

						}
					}
				}
			}).start();
	}
//自动返回
    public void do_back() {
        AccessibilityNodeInfo action = getRootInActiveWindow();
        List<AccessibilityNodeInfo> nodes = action.findAccessibilityNodeInfosByText("返回");
        if (!nodes.isEmpty()&&isBack) {
            nodes.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
    }
////附近点赞
//public void near_zan(){
//    new Thread(new Runnable() {
//        @Override
//        public void run() {
//            try {
//                Thread.sleep(2000);
//                AccessibilityNodeInfo action = getRootInActiveWindow();
//                List<AccessibilityNodeInfo> nodeInfos = action.findAccessibilityNodeInfosByText("赞");
//                for (int i = 0; i < 10; i++) {
//                    if(!nodeInfos.isEmpty()){
//                        nodeInfos.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);}
//
//                }
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//
//
//        }
//    }).start();
//}
    @Override
    public void onInterrupt() {

    }

}

