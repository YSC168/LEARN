package com.learn.app.Data;

import android.app.*;
import android.content.*;
import android.net.*;
import android.preference.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.util.regex.*;

public class method extends Application
{
	private SharedPreferences setting;
	@Override
	public void onCreate()
	{
		super.onCreate();
		setting=PreferenceManager.getDefaultSharedPreferences(this);
	}
	public void editString(String s,String message){
		setting.edit().putString(s,message).commit();
	}

	public void editBoolean(String s,boolean message){
		setting.edit().putBoolean(s,message).commit();
	}

	public void editint(String s,int message){
		setting.edit().putInt(s,message).commit();
	}

	public int getint(String s,int message){
		return setting.getInt(s,message);
	}

	public boolean getBoolean(String s,boolean message){
		return setting.getBoolean(s,message);
	}

	public String getString(String s,String message){
		return setting.getString(s,message);
	}

	public void showToast(String s){
		Toast.makeText(this,s,1000).show();
	}
	public void scanim(float from ,float to,long duration,View v){
		Animation anim=new ScaleAnimation(from,to,from,to,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
		anim.setDuration(duration);
		anim.setFillAfter(true);
		v.setAnimation(anim);
		anim.startNow();
		v.startAnimation(anim);
	}
	public void tranim(float fromx,float fromy,float tox,float toy,long duration,View v){
		Animation translate=new TranslateAnimation(fromx,tox,fromy,toy);
		translate.setDuration(duration);
		translate.setFillAfter(true);
		v.setAnimation(translate);
		translate.startNow();
		v.startAnimation(translate);
	}
	public void alanim(float from,float to,long duration,View v){
		Animation alpha=new AlphaAnimation(from,to);
		alpha.setDuration(duration);
		alpha.setFillAfter(true);
		v.setAnimation(alpha);
		alpha.startNow();
		v.startAnimation(alpha);
	}
	public LayoutAnimationController getListAnim() {
		AnimationSet set = new AnimationSet(true);
		Animation animation = new AlphaAnimation(0.0f, 1.0f);
		animation.setDuration(500);
		set.addAnimation(animation);
		animation=new ScaleAnimation(0.5f,1f,0.5f,1f,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
		animation.setDuration(200);
		set.addAnimation(animation);
		LayoutAnimationController controller = new LayoutAnimationController(
			set, 0.5f);
		return controller;
	}
}

