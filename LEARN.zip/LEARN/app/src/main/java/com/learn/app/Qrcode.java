package com.learn.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.google.zxing.*;
import com.zxing.encoding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;

public class Qrcode extends Fragment implements OnClickListener
{
	private Uri imageFileUri;
	private android.app.AlertDialog dialog;
	protected static final int RESULT_SPEECH = 1;
	private EditText qrStrEditText;
	private ImageView qrImgImageView;
	private TextView tv;
	TextView sjsj;
	Calendar now = new GregorianCalendar();
	public static final int MSG_ONE = 1;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            //通过消息的内容msg.what  分别更新ui
            switch (msg.what) {
                case MSG_ONE:
                    //获取到系统当前时间 long类型
                    long time = System.currentTimeMillis();
                    //将long类型的时间转换成日历格式
                    Date data = new Date(time);
                    // 转换格式，年月日时分秒 星期  的格式
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM月dd日HH时mm分");
                    //显示在textview上，通过转换格式
                    sjsj.setText(simpleDateFormat.format(data));
                    break;
                default:
                    break;
            }}};
	@Override
	public void onClick(View p1)
	{
		// TODO: Implement this method
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
		return inflater.inflate(R.layout.qrcode, container, false);
	}
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
		//setHasOptionsMenu(true);//Fragment添加菜单
		sjsj = (TextView)getActivity().findViewById(R.id.sjsj);
		new TimeThread().start();
	    tv=(TextView)this.getActivity().findViewById(R.id.qrcodecontent);
        qrStrEditText = (EditText) this.getActivity().findViewById(R.id.et_qr_string);
        qrImgImageView = (ImageView) this.getActivity().findViewById(R.id.iv_qr_image);
		Button scanBarCodeButton = (Button) this.getActivity().findViewById(R.id.btn_add_qrcode);
        scanBarCodeButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					try {
						String contentString = qrStrEditText.getText().toString();
						if (!contentString.equals("")) {   //判断输入框是否有文字
							//根据字符串生成二维码图片并显示在界面上，第二个参数为图片的大小（600*600）
							Bitmap qrCodeBitmap = EncodingHandler.createQRCode(contentString, 1200);
							qrImgImageView.setImageBitmap(qrCodeBitmap);
							String str1=null;
							str1=qrStrEditText.getText().toString();
							tv.setText(str1);
							qrImgImageView.setVisibility(View.VISIBLE);
							Toast.makeText(getActivity(), "生成成功，点击图片保存！", Toast.LENGTH_SHORT).show();
							
						}else {
							qrImgImageView.setVisibility(View.INVISIBLE);
							Toast.makeText(getActivity(), "文本为空！", Toast.LENGTH_SHORT).show();
						}
					} catch (WriterException e) {
						e.printStackTrace();
					}}});
		qrImgImageView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					showDialog("保存","是否保存并分享？","是","仅保存",0);
				}});
	}

	@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.qrmenu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
		if (id == R.id.voice ){
			
	
		}
        if (id == R.id.three ) {

            return true;
        } else
            return super.onOptionsItemSelected(item);

    }
	private void showDialog(String T,String M,String ok,String qx,final int i) {
		dialog = new AlertDialog.Builder(getActivity()).setTitle(T)
			.setMessage(M)
			//.setCancelable(false)
			.setPositiveButton(ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					switch(i){
						case 0:
							qrImgImageView.buildDrawingCache(true);  
							qrImgImageView.buildDrawingCache();  
							Bitmap bitmap = qrImgImageView.getDrawingCache();  
							saveBitmapFile(bitmap);
							qrImgImageView.setDrawingCacheEnabled(false);
							Intent shareIntent = new Intent();
							shareIntent.setAction(Intent.ACTION_SEND);
							shareIntent.putExtra(Intent.EXTRA_STREAM, imageFileUri);
							shareIntent.setType("image/*");
							startActivity(Intent.createChooser(shareIntent, "分享到"));
							break;
					}
					dialog.dismiss();
				}
			})
			.setNegativeButton(qx, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					qrImgImageView.buildDrawingCache(true);  
					qrImgImageView.buildDrawingCache();  
					Bitmap bitmap = qrImgImageView.getDrawingCache();  
					saveBitmapFile(bitmap);
					qrImgImageView.setDrawingCacheEnabled(false);
					Toast.makeText(getActivity(), "保存在sdcard/YSC_APP/二维码", Toast.LENGTH_LONG).show();
				}
			}).create();

		dialog.show();
	}
	
	public void saveBitmapFile(Bitmap bitmap){
		File temp = new File("/sdcard/YSC_APP/二维码/");//要保存文件先创建文件夹   
		if (!temp.exists()) {
			temp.mkdir();
		}
        File file=new File(temp+"/"+ sjsj.getText() +".png");//将要保存图片的路径和图片名称
		//直接保存到sd卡不需要创建文件夹 并使用时间去命名图片的名字不会重复
		imageFileUri = Uri.fromFile(file);
		try {
			BufferedOutputStream bos= new BufferedOutputStream(new FileOutputStream(file));
			bitmap.compress(Bitmap.CompressFormat.PNG, 50, bos);
			bos.flush();
			bos.close();
        } catch (IOException e) {
			e.printStackTrace();
        }
	}

	public class TimeThread extends Thread {
        //重写run方法
        @Override
        public void run() {
            super.run();

            do {
                try {
                    //每隔一秒 发送一次消息
                    Thread.sleep(1000);
                    Message msg = new Message();
                    //消息内容 为MSG_ONE
                    msg.what = MSG_ONE;
                    //发送
                    handler.sendMessage(msg);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } while (true);
		}}}
