package com.learn.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.support.v4.view.*;
import android.support.v4.view.ViewPager.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.learn.app.*;
import com.learn.app.Data.*;
import com.learn.app.View.*;
import java.util.*;
import android.view.View.OnClickListener;
import android.support.v7.app.*;

public class Views extends AppCompatActivity implements OnPageChangeListener
{
	private String onviewClick="FIRST";
	private ViewPager vp;  
    private MyPagerAdapter vpAdapter;  
    private List<View> views;
	private View View1,View2,View3;
	private Button b1,b2,b3;
	private ImageView i3;
	private method me;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		//设置全屏
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
							 WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.views);
		init();
	}

	private void init(){
		me = (method) getApplication();
		if(me.getBoolean(onviewClick,false)==false){
			initViews();
		}else{
			Intent i=new Intent(Views.this,Splash.class);
			startActivity(i);
			finish();
		}
	}

	private void initViews() {  
        LayoutInflater inflater = LayoutInflater.from(this);  
        views = new ArrayList<View>();
		View1=inflater.inflate(R.layout.one, null);
		View2=inflater.inflate(R.layout.two, null);
		View3=inflater.inflate(R.layout.three,null);
		views.add(View1);
		views.add(View2);
		views.add(View3);
        vpAdapter = new MyPagerAdapter(views,this);
        vp = (ViewPager) findViewById(R.id.viewpager);
        vp.setAdapter(vpAdapter);  
        vp.setOnPageChangeListener(this);
		b1=(Button)View1.findViewById(R.id.oneButton1);
		b1.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					vp.setCurrentItem(1);
				}
			});
		b2=(Button)View2.findViewById(R.id.twoButton1);
		b2.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					vp.setCurrentItem(2);
				}
			});
		b3=(Button)View3.findViewById(R.id.threeButton1);
		b3.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					me.editBoolean(onviewClick,true);
					Intent i=new Intent(Views.this,MainActivity.class);
					startActivity(i);
					finish();
				}
			});
		i3=(ImageView)View3.findViewById(R.id.threeImageView1);
	}

	@Override
	public void onPageScrolled(int p1, float p2, int p3)
	{
	}

	@Override
	public void onPageSelected(int p1)
	{
	}

	@Override
	public void onPageScrollStateChanged(int p1)
	{
		if(p1==2){
			me.scanim(0.0f,1f,2000,i3);
		}
	}
	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		finish();
	}
}

