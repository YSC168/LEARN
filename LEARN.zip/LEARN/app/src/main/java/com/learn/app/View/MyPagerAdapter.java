package com.learn.app.View;

import com.learn.app.*;
import android.app.*;
import android.support.v4.view.*;
import android.view.*;
import java.util.*;

public class MyPagerAdapter extends PagerAdapter
{
	private List<View> mListViews;
	Activity activity;

	public MyPagerAdapter(List<View> mListViews,Activity activity){
		this.mListViews=mListViews;
		this.activity=activity;
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object)
	{
		container.removeView(mListViews.get(position));
	}

	@Override
	public Object instantiateItem(ViewGroup container, int position)
	{
		container.addView(mListViews.get(position));
		return mListViews.get(position);
	}
	@Override
	public int getCount()
	{
		return mListViews.size();
	}

	@Override
	public boolean isViewFromObject(View p1, Object p2)
	{
		return p1==p2;
	}
}

