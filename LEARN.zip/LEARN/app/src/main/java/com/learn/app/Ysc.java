package com.learn.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.view.Window;
import android.widget.Toast;
import java.io.InputStream;
import java.io.IOException;
import android.widget.EditText;
import android.net.Uri;
import android.net.*;
import android.graphics.*;
import java.io.*;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import android.util.*;
import android.widget.*;
import android.support.v7.app.*;
import java.util.*;
import android.content.SharedPreferences;
import android.support.v7.widget.Toolbar;
import android.support.design.widget.*;
import android.speech.tts.*;
import android.speech.tts.TextToSpeech.*;
import android.text.method.*;
public class Ysc extends AppCompatActivity implements ColorPicker.OnColorChangeListener{
private	TextToSpeech mSpeech;
	private int mColor;
    private SharedPreferences mSharedPreferences;
    private SharedPreferences.Editor mEditor;
	//输入框
    private EditText et_number;
    //测试按钮
    private Button btn_qq;
    //输出结果
    private TextView tv_result;
	ImageView nLogoBtnIv;
	LinearLayout nContentLayout;
	FrameLayout colorLayout;
	boolean isContentVisible = true;
	public static  SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
		sp = getSharedPreferences("config",Context. MODE_PRIVATE);    
        String selectcolor = sp.getString("color", ""); 
		//姨妈红
        if(selectcolor.equals("-769226")){
            setTheme(R.style.RedTheme);   
        }
        //原谅绿
        else if (selectcolor.equals("-11751600")){
            setTheme(R.style.GreenTheme);
        }
        //天空蓝
        else if(selectcolor.equals("-14575885")){
            setTheme(R.style.BlueTheme);
        }
        //卡其褐
        else if(selectcolor.equals("-8825528")){
            setTheme(R.style.BrowmTheme);
        }
        //太空灰
        else if(selectcolor.equals("-6381922")){
            setTheme(R.style.GreyTheme);
        }
        //哔哩粉
        else if(selectcolor.equals("-1499549")){
            setTheme(R.style.PinkTheme);
        }
        //基佬紫
        else if(selectcolor.equals("-6543440")){
            setTheme(R.style.PurpleTheme);
        }
        //橘子橙
        else if(selectcolor.equals("-26624")){
            setTheme(R.style.OrangeTheme);
        }
        //水鸭青
        else if(selectcolor.equals("-16738680")){
            setTheme(R.style.TealTheme);
        }
		super.onCreate(savedInstanceState);
        setContentView(R.layout.ysc);
		Toast.makeText(Ysc.this, "此测试仅供娱乐(๑>؂<๑）", Toast.LENGTH_SHORT).show();
		Toolbar toolBar= (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolBar);
		toolBar.setTitleTextColor(Color.WHITE);
		setActionBar();
		colorLayout = (FrameLayout) findViewById(R.id.color);
        init();
        initView();
		nContentLayout = (LinearLayout) findViewById(R.id.content_layout);
		nLogoBtnIv = (ImageView) findViewById(R.id.logoBtn_iv);
		nLogoBtnIv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					view.animate().rotationBy(90);
					// 以 @mLogoBtnIv 为中心，收缩或伸展 @mContentLayout
					if (isContentVisible)
						CircularAnimUtil.hideOther(nLogoBtnIv, nContentLayout);
					else
						CircularAnimUtil.showOther(nLogoBtnIv, nContentLayout);
					isContentVisible = !isContentVisible;
				}
			});
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.other, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
if(id==android.R.id.home){
	onBackPressed();
}
		if (id == R.id.display){
			colorLayout.setBackgroundColor(getRandomColor());
            return true;
		}
		if(id==R.id.colorpick){
			new ColorPicker(this, this, mColor).show();
			return true;
		}
		if(id==R.id.theme1){
			Context context = getApplicationContext();
			String msg = "代码已生成，粘贴到编辑框即可";
			int duration = Toast.LENGTH_SHORT;
			Toast toast = Toast.makeText(context, msg, duration);
			int offsetX = 0;
			int offsetY = 100;
			toast.setGravity(Gravity.BOTTOM, offsetX, offsetY);
			toast.show(); 
			try {  	
				InputStream is = getAssets().open("kaqq.txt");  
				int size = is.available();    
				byte[] buffer = new byte[size];
				is.read(buffer);  
				is.close();   
				String text = new String(buffer, "utf-8");  
				StringBuffer b = new StringBuffer("");
				ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				b.append(text);
				manager.setText(b);
				Intent intent = new Intent();
				intent.setAction(Intent.ACTION_SEND);
				intent.setType("text/plain");
				intent.putExtra(Intent.EXTRA_TEXT, text);
				startActivity(Intent.createChooser(intent, "分享到..."));
			} catch (IOException e) {  
				throw new RuntimeException(e);  }
			return true;
		}
		if(id==R.id.suijishu){
			final EditText et_sjs = new EditText(this);
			et_sjs.setText("");
			et_sjs.setKeyListener(DigitsKeyListener.getInstance("0123456789")); 
			et_sjs.setSelection(et_sjs.length());
			et_sjs.setGravity(Gravity.CENTER);
			android.app.AlertDialog.Builder suijishu=new android.app.AlertDialog.Builder(this)
				.setTitle("输入生成位数")
				.setView(et_sjs);
			suijishu.setIcon(R.drawable.ic_bookmark_24dp);
			suijishu.setNegativeButton("取消", null)
				.setPositiveButton(
				"确定",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{String in = et_sjs.getText().toString(); 
						if(in.equals("")){
							Toast.makeText(Ysc.this, "没有输入!", Toast.LENGTH_SHORT).show();
						}else{
							String str1=null;
							
							str1=et_sjs.getText().toString();	
							Long num1=Long.valueOf(str1);
							Random random = new Random();
							String result="";
							for(int i=0;i<num1;i++){
								result+=random.nextInt(10);
							}
							System.out.print(result);

							
							Toast.makeText(Ysc.this, result, Toast.LENGTH_LONG).show();
							ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
							manager.setText(result);
							Snackbar.make(colorLayout, "已复制在剪贴板", Snackbar.LENGTH_LONG).show();
						}
					}
				});suijishu.show();
			
			return true;
		}
		if(id==R.id.shaizhi){
			final EditText et_sz = new EditText(this);
			et_sz.setText("");
			et_sz.setKeyListener(DigitsKeyListener.getInstance("0123456789")); 
			et_sz.setSelection(et_sz.length());
			et_sz.setGravity(Gravity.CENTER);
			android.app.AlertDialog.Builder shaizhi=new android.app.AlertDialog.Builder(this)
				.setTitle("输入骰子个数")
				.setView(et_sz);
			shaizhi.setIcon(R.drawable.ic_bookmark_24dp);
			shaizhi.setNegativeButton("取消", null)
				.setPositiveButton(
				"确定",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{String in = et_sz.getText().toString(); 
						if(in.equals("")){
							Toast.makeText(Ysc.this, "没有输入!", Toast.LENGTH_SHORT).show();
						}else{
							String str1=null;

							str1=et_sz.getText().toString();	
							Long num1=Long.valueOf(str1);
							Random random = new Random();
							String result="";
							for(int i=0;i<num1;i++){
								result+=random.nextInt(6)+1;
								
							}
							System.out.print(result);


							Toast.makeText(Ysc.this, result, Toast.LENGTH_LONG).show();
							ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
							manager.setText(result);
							Snackbar.make(colorLayout, "已复制在剪贴板", Snackbar.LENGTH_LONG).show();
						}
					}
				});shaizhi.show();
			
		}
		if(id==R.id.voice){
	 
			mSpeech = new TextToSpeech(this, new OnInitListener() {

					@Override
					public void onInit(int status) {
						// TODO Auto-generated method stub
						if (status == TextToSpeech.SUCCESS) {
							int result = mSpeech.setLanguage(Locale.ENGLISH);
							if (result == TextToSpeech.LANG_MISSING_DATA
								|| result == TextToSpeech.LANG_NOT_SUPPORTED) {
								Log.e("lanageTag", "not use");
							} else {
								mSpeech.speak("let's begin", TextToSpeech.QUEUE_FLUSH,
											  null);
							}
						}
					}
				});
				
			final EditText et_voice = new EditText(this);
			et_voice.setText("");
			et_voice.setSelection(et_voice.length());
			et_voice.setGravity(Gravity.CENTER);
			android.app.AlertDialog.Builder weblist=new android.app.AlertDialog.Builder(this)
				.setTitle("输入英语")
				.setView(et_voice);
			weblist.setIcon(R.drawable.ic_bookmark_24dp);
			weblist.setNegativeButton("取消", null)
				.setPositiveButton(
				"确定",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{String in = et_voice.getText().toString(); 
						if(in.equals("")){
							Toast.makeText(Ysc.this, "没有输入!", Toast.LENGTH_SHORT).show();
						}else{
							String str1=null;
							str1=et_voice.getText().toString();		
							mSpeech.speak(str1,
										  TextToSpeech.QUEUE_FLUSH, null);
						}
					}
				});weblist.show();
		}
		if(id==R.id.theme2){
			if (!isRoot())
			{
				Toast.makeText(this, "没有ROOT权限", Toast.LENGTH_SHORT).show();
				
			}
			if(isRoot()){
				Toast.makeText(this, "已获取ROOT权限", Toast.LENGTH_SHORT).show();
				
			}
		}
		
		return super.onOptionsItemSelected(item);
    }
	@Override
    public void onColorChange(int color)
    {
        // TODO: Implement this method
        mColor = color;
        colorLayout.setBackgroundColor(mColor);
        mEditor.putInt("color", mColor);
        mEditor.commit();
    }
    private void init() {
        mSharedPreferences = getPreferences(MODE_PRIVATE);
        mEditor = mSharedPreferences.edit();
        if (mSharedPreferences.contains("color")) {
            mColor = mSharedPreferences.getInt("color", -1);
            colorLayout.setBackgroundColor(mColor);
        } else {
			//  mColor = mTextView.getTextColors().getDefaultColor();
            mEditor.putInt("color", mColor);
            mEditor.commit();
        }
    }
	public int getRandomColor() {
        Random rand = new Random();
        return Color.argb(100, rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
    }
	public void color(View v){

		new ColorPicker(this, this, mColor).show();
	}
	/**
     * 初始化View
     */
    private void initView() {
        et_number = (EditText) findViewById(R.id.et_number);
        btn_qq = (Button) findViewById(R.id.btn_qq);
        tv_result = (TextView) findViewById(R.id.tv_result);
        //点击事件
        btn_qq.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					
					//拿到输入的内容
					String qq = et_number.getText().toString();
					Volley_Get(qq);
				}
			});
    }

    /**
     * 解析接口
     *
     * @param qq 你输入的QQ号码
     */
    private void Volley_Get(String qq) {
        //接口
        String url = "http://japi.juhe.cn/qqevaluate/qq?key=8d9160d4a96f2a6b5316de5b9d14d09d&qq=" + qq;

        //定义网络请求队列
        RequestQueue queue = Volley.newRequestQueue(this);
        //建立对象
        StringRequest string = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
				@Override
				public void onResponse(String s) {
					Log.i("json", s);
					getJson(s);
				}
			}, new Response.ErrorListener() {
				@Override
				public void onErrorResponse(VolleyError volleyError) {

				}
			});
        //把对象添加到队列中去
        queue.add(string);
    }
    /**
     * 解析json
     *
     * @param s json
     */
    private void getJson(String s) {
        try {
            JSONObject json = new JSONObject(s);
            JSONObject json1 = json.getJSONObject("result");
            JSONObject json2 = json1.getJSONObject("data");
            //设置数据
            tv_result.setText("测试结果：" + json2.getString("conclusion") + "\n"
							  + "分析结果：" + json2.getString("analysis"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
	private void setActionBar() {
        setTitle(getResources().getString(R.string.qt));
        try {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
	public boolean isRoot()
    {
        boolean bool = false;
        try
		{
            bool = new File("/system/bin/su").exists() || new File("/system/xbin/su").exists();
        }
		catch (Exception e)
		{
            e.printStackTrace();
        }
        return bool;
    }
	@Override
    public void onBackPressed() {
        super.onBackPressed();
        // 添加返回过渡动画.
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    }
}


