package com.learn.app;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

public class NetWorkChange extends BroadcastReceiver
{
	private Context mcontext;
	public NetWorkChange(Context context){
		mcontext=context;
	}
	@Override
	public void onReceive(Context p1, Intent p2)
	{
		p1=mcontext;

		//获取网络连接
		ConnectivityManager cm = (ConnectivityManager) 
			p1.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkinfo=cm.getActiveNetworkInfo();
		//判断网络连接
		if(networkinfo!=null&&networkinfo.isAvailable()){

			Toast.makeText(p1,"网络已连接",Toast.LENGTH_SHORT).show();

		}else{

		Toast.makeText(p1,"网络连接已关闭",Toast.LENGTH_SHORT).show();
		}
	}
}

