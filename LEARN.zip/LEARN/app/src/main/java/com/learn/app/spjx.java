package com.learn.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.widget.*;
import com.tencentqq.widget.*;
import android.content.pm.*;
import android.content.SharedPreferences;
import es.dmoral.toasty.*;

public class spjx extends Activity
{
	private EditText ed;
	private Button bt1;
	private WebView qiyWeb;
	
	private String Url="http://yun.mt2t.com/yun?url=";
	public static  SharedPreferences sp;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		sp = getSharedPreferences("config",Context. MODE_PRIVATE);    
        String selectcolor = sp.getString("color", ""); 
		//姨妈红
        if(selectcolor.equals("-769226")){
            setTheme(R.style.RedTheme);   
        }
        //原谅绿
        else if (selectcolor.equals("-11751600")){
            setTheme(R.style.GreenTheme);
        }
        //天空蓝
        else if(selectcolor.equals("-14575885")){
            setTheme(R.style.BlueTheme);
        }
        //卡其褐
        else if(selectcolor.equals("-8825528")){
            setTheme(R.style.BrowmTheme);
        }
        //太空灰
        else if(selectcolor.equals("-6381922")){
            setTheme(R.style.GreyTheme);
        }
        //哔哩粉
        else if(selectcolor.equals("-1499549")){
            setTheme(R.style.PinkTheme);
        }
        //基佬紫
        else if(selectcolor.equals("-6543440")){
            setTheme(R.style.PurpleTheme);
        }
        //橘子橙
        else if(selectcolor.equals("-26624")){
            setTheme(R.style.OrangeTheme);
        }
        //水鸭青
        else if(selectcolor.equals("-16738680")){
            setTheme(R.style.TealTheme);
        }
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); 
		
		setContentView(R.layout.spjx);
		ed = (EditText) findViewById(R.id.qiyed2);
		bt1 = (Button) findViewById(R.id.qiybt2);
		qiyWeb = (WebView) findViewById(R.id.qiyWeb2);
		qiyWeb.setBackgroundColor(0);
		bt1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					String s=ed.getText().toString();
					if (s.equals(""))
					{
						Toasty.error(spjx.this, "请输入播放地址！", Toast.LENGTH_LONG).show();			
						//Toasty.error(spjx.this, "请输入播放地址！", Toast.LENGTH_LONG).show();
					}
					else
					{
						Toasty.success(spjx.this, "播放后黑屏是在解析状态中，解析时间与接口和你的网速有关，一般需要1-4分钟，请耐心等待！",
									   Toast.LENGTH_SHORT).show();
						ed.setText("");
					}
					// WebView加载web资源
					qiyWeb.loadUrl(Url + s);

					//  启用支持javascript
					WebSettings settings = qiyWeb.getSettings();
					settings.setJavaScriptEnabled(true);
					settings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					// 覆盖WebView默认使用第三方或系统默认浏览器打开网页的行为，使网页用WebView打开
					qiyWeb.setWebViewClient(new WebViewClient() {
							@Override
							public boolean shouldOverrideUrlLoading(WebView view, String url)
							{
								//  TODO Auto-generated method stub
								//  返回值是true的时候控制去WebView打开，为false调用系统浏览器或第三方浏览器
								view.loadUrl(url);
								return true;
							}
						});
				}});}
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
	@Override
    public void onBackPressed() {
        super.onBackPressed();
        // 添加返回过渡动画.
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    }
}
