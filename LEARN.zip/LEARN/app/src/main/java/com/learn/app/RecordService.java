package com.learn.app;

import android.app.*;
import android.content.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import android.util.*;
import android.view.*;
import es.dmoral.toasty.*;

public class RecordService extends Service
{
	public static MediaProjection mediaProjection;
	public static MediaRecorder mediaRecorder;
	public static VirtualDisplay virtualDisplay;
	public static boolean running=false;
	private int width =720;
	private int height = 1180;
	//int widt = getWindowManager().getDefaultDisplay().getWidth();
	private int dpi;

	@Override
	public IBinder onBind ( Intent intent )
	{
		return new RecordBinder ( );
	}
	@Override
	public int onStartCommand ( Intent intent, int flags, int startId )
	{
		return START_STICKY;
	}

	@Override
	public void onCreate ( )
	{
		super.onCreate ( );
		HandlerThread serviceThread = new HandlerThread ( "YSC_APP",
														 android.os.Process.THREAD_PRIORITY_BACKGROUND );
		serviceThread.start ( );
		mediaRecorder = new MediaRecorder ( );
	}

	@Override
	public void onDestroy ( )
	{
		Toasty.error(this,"停止",500).show();
		running = false;
		mediaRecorder.stop ( );
		mediaRecorder.reset ( );
		virtualDisplay.release ( );
		mediaProjection.stop ( );
	}
	
	public void setMediaProject ( MediaProjection project )
	{
		mediaProjection = project;
	}

	public boolean isRunning ( )
	{
		return running;
	}

	public void setConfig ( int width, int height, int dpi )
	{
		this.width = width;
		this.height = height;
		this.dpi = dpi;
	}

	public boolean startRecord ( )
	{
		if ( mediaProjection == null || running )
		{
			return false;
		}

		initRecorder ( );
		createVirtualDisplay ( );
		mediaRecorder.start ( );
		running = true;
		return true;
	}
    /**
     * 获得屏幕宽度
     */
    public static int w(Context context) {
        WindowManager wm = (WindowManager) context
			.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.widthPixels;
    }
	public boolean stopRecord ( )
	{
		if ( !running )
		{
			return false;
		}
		running = false;
		mediaRecorder.stop ( );
		mediaRecorder.reset ( );
		virtualDisplay.release ( );
		mediaProjection.stop ( );
		return true;
	}

	private void createVirtualDisplay ( )
	{
		virtualDisplay = mediaProjection.createVirtualDisplay ( "MainScreen", width, height, dpi,
															   DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, mediaRecorder.getSurface ( ), null, null );
	}

	private void initRecorder ( )
	{
		if ( Video.sy )
		{
			mediaRecorder.setAudioSource ( MediaRecorder.AudioSource.MIC );
			mediaRecorder.setVideoSource ( MediaRecorder.VideoSource.SURFACE );
			mediaRecorder.setOutputFormat ( MediaRecorder.OutputFormat.THREE_GPP );
			SimpleDateFormat    sDateFormat    =   new    SimpleDateFormat ( "yyyy.MM.dd.hh.mm.ss" );     
			String    date    =    sDateFormat.format ( new    java.util.Date ( ) );  
			mediaRecorder.setOutputFile ( getsaveDirectory ( ) + date + ".mp4" );
			mediaRecorder.setVideoSize ( width, height );
			mediaRecorder.setVideoEncoder ( MediaRecorder.VideoEncoder.H264 );
			mediaRecorder.setAudioEncoder ( MediaRecorder.AudioEncoder.AMR_NB );
			mediaRecorder.setVideoEncodingBitRate ( 5 * 1024 * 1024 );
			mediaRecorder.setVideoFrameRate ( 30 );
		}
		else
		{
			mediaRecorder.setVideoSource ( MediaRecorder.VideoSource.SURFACE );
			mediaRecorder.setOutputFormat ( MediaRecorder.OutputFormat.THREE_GPP );
			SimpleDateFormat    sDateFormat    =   new    SimpleDateFormat ( "yyyy.MM.dd.hh.mm.ss" );     
			String    date    =    sDateFormat.format ( new    java.util.Date ( ) );  
			mediaRecorder.setOutputFile ( getsaveDirectory ( ) + date + ".mp4" );
			mediaRecorder.setVideoSize ( width, height );
			mediaRecorder.setVideoEncoder ( MediaRecorder.VideoEncoder.H264 );
			mediaRecorder.setVideoEncodingBitRate ( 5 * 1024 * 1024 );
			mediaRecorder.setVideoFrameRate ( 30 );
		}
		try
		{
			mediaRecorder.prepare ( );
		}
		catch (IOException e)
		{
			e.printStackTrace ( );
		}
	}
	public String getsaveDirectory ( )
	{
		if ( Environment.getExternalStorageState ( ).equals ( Environment.MEDIA_MOUNTED ) )
		{
			String rootDir = Environment.getExternalStorageDirectory ( ).getAbsolutePath ( ) + "/" + "YSC_APP" + "/" + "屏幕录制" + "/";

			File file = new File ( rootDir );
			if ( !file.exists ( ) )
			{
				if ( !file.mkdirs ( ) )
				{
					return null;
				}
			}
			Toasty.success( getApplicationContext ( ), rootDir, Toast.LENGTH_SHORT ).show ( );
			return rootDir;
		}
		else
		{
			return null;
		}
	}
	public class RecordBinder extends Binder
	{
		public RecordService getRecordService ( )
		{
			return RecordService.this;
		}
	}
}
