package com.learn.app.tab;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.learn.app.*;

public class pager_window_02 extends Fragment {
    private static final String ARG_POSITION = "position";
    private int position;

    public static pager_window_02 newInstance(int position) {
        pager_window_02 f = new pager_window_02();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        position = getArguments().getInt(ARG_POSITION);
        View rootView = inflater.inflate(R.layout.layout_pager_window_02, container, false);
		
        switch (position) {
            case 0:
                break;
        }
        return rootView;
    }
	
}

