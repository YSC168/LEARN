package com.learn.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.*;
import android.os.*;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.Intent;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import com.bumptech.glide.*;
import java.io.*;
import android.graphics.*;
import android.support.design.widget.*;
import android.preference.*;
import com.bumptech.glide.Glide;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import java.text.*;
import android.net.*;
import android.support.design.widget.Snackbar;
public class BingPic extends Activity 
{
	private ImageView bingPicMain;
	TextView bing;
	private Uri imageFileUri;
	public static final int MSG_ONE = 1;
	private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            //通过消息的内容msg.what  分别更新ui
            switch (msg.what) {
                case MSG_ONE:
                    //获取到系统当前时间 long类型
                    long time = System.currentTimeMillis();
                    //将long类型的时间转换成日历格式
                    Date data = new Date(time);
                    // 转换格式，年月日时分秒 星期  的格式
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM月dd日");
                    //显示在textview上，通过转换格式
                    bing.setText(simpleDateFormat.format(data));
                    break;
                default:
                    break;
            }}};
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		//设置全屏
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
							 WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bingpic);
		new TimeThread().start();
		bing = (TextView)findViewById(R.id.bing);
		bingPicMain = (ImageView) findViewById(R.id.bing_pic_im);
		SharedPreferences prefmain = PreferenceManager.getDefaultSharedPreferences(this);
		String bingPicmain = prefmain.getString("bing_pic", null);
        if (bingPicmain != null) {
			loadBingPicMain();
            Glide.with(this).load(bingPicmain).into(bingPicMain);
        } else {
            loadBingPicMain();
        }
		bingPicMain.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					File file=new File("/sdcard/YSC_APP/必应图片/"+"/"+ bing.getText()+".png");
					if (!file.exists()) {
						bingPicMain.buildDrawingCache(true);  
						bingPicMain.buildDrawingCache();  
						Bitmap bitmap = bingPicMain.getDrawingCache();  
						saveBitmapFile(bitmap);
						bingPicMain.setDrawingCacheEnabled(false);
						//Snackbar.make(bingPicMain, "保存在sdcard/YSC_APP/必应图片", Snackbar.LENGTH_LONG).show();
						Toast.makeText(BingPic.this, "保存在sdcard/YSC_APP/必应图片", Toast.LENGTH_LONG).show();
					}
					else{
						//Snackbar.make(bingPicMain, "已经保存过了", Snackbar.LENGTH_LONG).show();
						Toast.makeText(BingPic.this, "已经保存过了", Toast.LENGTH_LONG).show();
					}
				}
			});
	}
	/**
     * 加载必应每日一图
     */
    private void loadBingPicMain() {
		SharedPreferences prefmain = PreferenceManager.getDefaultSharedPreferences(this);
		String dbDate = prefmain.getString("datemain","");
        if (!dbDate.equals(getCurrentDayMain())){
            loadBngPicByIntMain();
            SharedPreferences.Editor editormain = PreferenceManager.getDefaultSharedPreferences(BingPic.this).edit();
            editormain.putString("datemain",getCurrentDayMain());
            editormain.apply();
        }else {

            String bingPicmain = prefmain.getString("bing_pic", null);
            if (bingPicmain != null) {
                Glide.with(getApplicationContext()).load(bingPicmain).crossFade().centerCrop().into(bingPicMain);
            } else {
                loadBngPicByIntMain();
            }
        }
    }
	private void loadBngPicByIntMain() {
        String requestBingPicmain = "http://guolin.tech/api/bing_pic";
        HttpUtil.sendOkHttpRequest(requestBingPicmain, new Callback() {
				@Override
				public void onFailure(Call call, IOException e) {
					e.printStackTrace();
				}

				@Override
				public void onResponse(Call call, Response response) throws IOException {
					final String bingPicmain = response.body().string();
					SharedPreferences.Editor editormain = PreferenceManager.getDefaultSharedPreferences(BingPic.this).edit();
					editormain.putString("bing_pic", bingPicmain);
					editormain.apply();
					runOnUiThread(new Runnable() {
							@Override
							public void run() {
								Glide.with(BingPic.this).load(bingPicmain).into(bingPicMain);
							}
						});
				}
			});
    }
	private String getCurrentDayMain() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sf = new SimpleDateFormat("MM月dd日");
        Date datemain = calendar.getTime();
        String szDate = sf.format(datemain);
		bing.setText(szDate);
        return szDate;
    }
	public void saveBitmapFile(Bitmap bitmap){
		File temp = new File("/sdcard/YSC_APP/必应图片/");//要保存文件先创建文件夹   
		if (!temp.exists()) {
			temp.mkdir();
		}
        File file=new File(temp+"/"+ bing.getText()+".png");//将要保存图片的路径和图片名称
		//直接保存到sd卡不需要创建文件夹 并使用时间去命名图片的名字不会重复
		imageFileUri = Uri.fromFile(file);
		try {
			BufferedOutputStream bos= new BufferedOutputStream(new FileOutputStream(file));
			bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
			bos.flush();
			bos.close();
        } catch (IOException e) {
			e.printStackTrace();
        }
	}
	public class TimeThread extends Thread {
        //重写run方法
        @Override
        public void run() {
            super.run();

            do {
                try {
                    //每隔一秒 发送一次消息
                    Thread.sleep(1000);
                    Message msg = new Message();
                    //消息内容 为MSG_ONE
                    msg.what = MSG_ONE;
                    //发送
                    handler.sendMessage(msg);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } while (true);
		}}
}
