package com.learn.app;


import android.app.*;
import android.os.*;
import android.widget.ListView;
import android.content.pm.PackageManager;
import java.util.List;
import android.content.pm.ApplicationInfo;
import java.util.ArrayList;
import android.content.pm.*;
import java.util.*;
import android.widget.AdapterView.*;
import android.widget.*;
import android.view.*;
import android.graphics.drawable.*;
import java.io.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.SharedPreferences;
import android.content.*;
import android.provider.*;
import android.net.*;
import android.support.design.widget.*;
import android.support.v4.content.*;
import android.*;
import android.support.v4.app.*;
public class AppActivity extends AppCompatActivity implements OnItemClickListener
{
	private DownloadService.DownloadBinder downloadBinder;
	private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            downloadBinder = (DownloadService.DownloadBinder) service;
        }

    };
	//Intent intent = new Intent(this, DownloadService.class);
	
	private ListView mListView;
	private PackageManager pm;
	private ArrayList<ApplicationInfo> applist;//全部应用
	private ArrayList<ApplicationInfo> applists;//安装的应用
	public static  SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		sp = getSharedPreferences("config",Context. MODE_PRIVATE);    
        String selectcolor = sp.getString("color", ""); 
		//姨妈红
        if(selectcolor.equals("-769226")){
            setTheme(R.style.RedTheme);   
        }
        //原谅绿
        else if (selectcolor.equals("-11751600")){
            setTheme(R.style.GreenTheme);
        }
        //天空蓝
        else if(selectcolor.equals("-14575885")){
            setTheme(R.style.BlueTheme);
        }
        //卡其褐
        else if(selectcolor.equals("-8825528")){
            setTheme(R.style.BrowmTheme);
        }
        //太空灰
        else if(selectcolor.equals("-6381922")){
            setTheme(R.style.GreyTheme);
        }
        //哔哩粉
        else if(selectcolor.equals("-1499549")){
            setTheme(R.style.PinkTheme);
        }
        //基佬紫
        else if(selectcolor.equals("-6543440")){
            setTheme(R.style.PurpleTheme);
        }
        //橘子橙
        else if(selectcolor.equals("-26624")){
            setTheme(R.style.OrangeTheme);
        }
        //水鸭青
        else if(selectcolor.equals("-16738680")){
            setTheme(R.style.TealTheme);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.applist);
		Toolbar toolBar= (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolBar);
		setActionBar();
		pm = getPackageManager();
		mListView = (ListView)findViewById(R.id.listview);
		mListView.setOnItemClickListener(this);
		applist = (ArrayList<ApplicationInfo>) pm.getInstalledApplications(ApplicationInfo.FLAG_UPDATED_SYSTEM_APP);
		//排序
		Collections.sort(applist,new ApplicationInfo.DisplayNameComparator(pm));
		applists = new ArrayList<ApplicationInfo>();
		getapp();
		//适配器
		MyAdapter adapter = new MyAdapter(this,applists);
		mListView.setAdapter(adapter);
		adapter.notifyDataSetChanged();
		Intent intent = new Intent(this, DownloadService.class);
        startService(intent); // 启动服务
        bindService(intent, connection, BIND_AUTO_CREATE); // 绑定服务
        if (ContextCompat.checkSelfPermission(AppActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(AppActivity.this, new String[]{ Manifest.permission. WRITE_EXTERNAL_STORAGE }, 1);
        }
		
    }

	private void getapp()
	{
		for(ApplicationInfo app : applist){
			if((app.flags & ApplicationInfo.FLAG_SYSTEM) <= 0){
				applists.add(app);
			}else if ((app.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0){
				applists.add(app);
			}
		}
	}
	@Override
	public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
	{
		popwindow(p3);
	
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.applist, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
			case android.R.id.home:
				onBackPressed();
				break;
				case R.id.learn:
				Intent i = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
				String pkg = "com.android.settings";
				String cls = "com.android.settings.applications.InstalledAppDetails";
				i.setComponent(new ComponentName(pkg, cls));
				i.setData(Uri.parse("package:" + getPackageName()));
				startActivity(i);
					break;
//					case R.id.call:
//						call();
//						break;
            case R.id.systemapplist:
                Intent intent = new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
				startActivity(intent);
                break;
            case R.id.install:
				//跟上面一样，只用修改输出流就可以了
				String fileName = "APK.apk";
//要保存的路径
				File file = new File("storage/sdcard0/"+fileName);
				try {
					InputStream in = getAssets().open(fileName);
					FileOutputStream out = new FileOutputStream(file);
					int len = -1 ;
					byte[] bytes = new byte[1024];
					while( (len=in.read(bytes) ) != -1){
						out.write(bytes,0,len);
					}
					out.close();
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				AlertDialog.Builder dialog = new AlertDialog.Builder(AppActivity.this);
				dialog.setTitle("安装软件");
				dialog.setMessage("•这是一个锁屏软件，画面感很美！\n•自己到storage/sdcard0/Download/文件下进行手动安装！（暂时不晓得怎么写了）\n•密码:ysc");
				dialog.setNegativeButton("取消", null);
				dialog.setPositiveButton("确认", new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							String url = "https://raw.githubusercontent.com/YSC168/eee/master/android.apk";
							downloadBinder.startDownload(url);
							Snackbar.make(mListView, "快去试试吧！", Snackbar.LENGTH_LONG).show();
						}
					});
				//创建并显示对话框
				AlertDialog alertDialog = dialog.create();
				alertDialog.show();
				
//				String str = "/CanavaCancel.apk";
//
//				Intent intentapp = new Intent(Intent.ACTION_VIEW);
//				intentapp.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
//				startActivity(intentapp);
//				
                break;
        }
        return super.onOptionsItemSelected(item);
    }
	private void popwindow(int p1)
	{
		ViewGroup pop = (ViewGroup)getLayoutInflater().inflate(R.layout.pop,null);
		ImageView icon = (ImageView) pop.findViewById(R.id.pop_app_icon);
		TextView packagename = (TextView) pop.findViewById(R.id.pop_packagename);
		TextView appname = (TextView) pop.findViewById(R.id.pop_appname);
		Button open=(Button)pop.findViewById(R.id.open);
		Button look=(Button)pop.findViewById(R.id.look);
		Button delete=(Button)pop.findViewById(R.id.delete);
		TextView size = (TextView) pop.findViewById(R.id.pop_size);

		ApplicationInfo p = applists.get(p1);
		packagename.setText("包名:"+p.packageName);
		appname.setText(p.loadLabel(pm));
		final String path=p.packageName;
		delete.setOnClickListener(new OnClickListener(){  
				@Override  
				public void onClick(View v) {  
				Intent intent=new Intent("android.intent.action.DELETE");
					intent.setData(Uri.parse("package:" + path));
					startActivity(intent);  
					
				}         
			});  
		open.setOnClickListener(new OnClickListener(){  
				@Override  
				public void onClick(View v) {  
					Intent intent = getPackageManager().getLaunchIntentForPackage( 
						path); 
					startActivity(intent);
				}         
			});  
		look.setOnClickListener(new OnClickListener(){  
				@Override  
				public void onClick(View v) {  
					Intent i = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
					String pkg = "com.android.settings";
					String cls = "com.android.settings.applications.InstalledAppDetails";
					i.setComponent(new ComponentName(pkg, cls));
					i.setData(Uri.parse("package:" + path));
					startActivity(i);
				}         
			});  
		float si=(float)new File(p.sourceDir).length()/1024/1024;
		DecimalFormat form= new DecimalFormat("##0.00");

		size.setText("大小:"+form.format(si)+"MB");
		icon.setImageDrawable(p.loadIcon(pm));
		PopupWindow popupWindow = new PopupWindow(pop, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		//获取焦点
		popupWindow.setFocusable(true);
		ColorDrawable dw = new ColorDrawable(0xb0000000);
		popupWindow.setBackgroundDrawable(dw);
		View view = (View) mListView.getParent();
		popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

	}
//	private void call() {
//        try {
//            Intent intent = new Intent(Intent.ACTION_CALL);
//            intent.setData(Uri.parse("tel:18996015174"));
//            startActivity(intent);
//        } catch (SecurityException e) {
//            e.printStackTrace();
//        }
//    }
//	@Override
//    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
//        switch (requestCode) {
//            case 1:
//                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    call();
//                } else {
//                    Toast.makeText(this, "没有权限拨打电话！", Toast.LENGTH_SHORT).show();
//                }
//                break;
//            default:
//        }
//    }
	
	private void setActionBar() {
        setTitle(getResources().getString(R.string.sjapp));
        try {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
	@Override
    public void onBackPressed() {
        super.onBackPressed();
        // 添加返回过渡动画.
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    }
}

