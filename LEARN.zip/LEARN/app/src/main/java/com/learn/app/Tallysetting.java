package com.learn.app;

import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.ListView;
import android.support.v7.widget.Toolbar;
import java.util.ArrayList;
import com.learn.app.adapter.*;
import android.graphics.*;
import android.content.SharedPreferences;
import android.content.*;
/*
 *  项目名：  TallyBook
 *  包名：    com.liuguilin.tallybook.ui
 *  文件名:   SettingActivity
 *  创建者:   LiuGuiLinAndroid
 *  创建时间:  2017/3/26 19:57
 *  描述：    设置
 */
public class Tallysetting extends AppCompatActivity {
    private ListView mListView;
    private ArrayList<String> mList = new ArrayList<>();
    private ListAdapter mAdapter;
	public static  SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
		sp = getSharedPreferences("config",Context. MODE_PRIVATE);    
        String selectcolor = sp.getString("color", ""); 
		//姨妈红
        if(selectcolor.equals("-769226")){
            setTheme(R.style.RedTheme);   
        }
        //原谅绿
        else if (selectcolor.equals("-11751600")){
            setTheme(R.style.GreenTheme);
        }
        //天空蓝
        else if(selectcolor.equals("-14575885")){
            setTheme(R.style.BlueTheme);
        }
        //卡其褐
        else if(selectcolor.equals("-8825528")){
            setTheme(R.style.BrowmTheme);
        }
        //太空灰
        else if(selectcolor.equals("-6381922")){
            setTheme(R.style.GreyTheme);
        }
        //哔哩粉
        else if(selectcolor.equals("-1499549")){
            setTheme(R.style.PinkTheme);
        }
        //基佬紫
        else if(selectcolor.equals("-6543440")){
            setTheme(R.style.PurpleTheme);
        }
        //橘子橙
        else if(selectcolor.equals("-26624")){
            setTheme(R.style.OrangeTheme);
        }
        //水鸭青
        else if(selectcolor.equals("-16738680")){
            setTheme(R.style.TealTheme);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tallysetting);
		Toolbar toolBar= (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolBar);
		toolBar.setTitleTextColor(Color.WHITE);
		setActionBar();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getSupportActionBar().setElevation(0);
        }

        initView();

    }

    private void initView() {
        mListView = (ListView) findViewById(R.id.mListView);

        mList.add("作者:YSC");
        mList.add("QQ:1643671159");
     
        mList.add("GitHub:https://github.com/YSC168");

        mAdapter = new ListAdapter(this, mList);
        mListView.setAdapter(mAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
	private void setActionBar() {
        setTitle(getResources().getString(R.string.qt));
        try {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
}

