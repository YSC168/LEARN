package com.learn.app;

import android.*;
import android.content.*;
import android.os.*;
import android.support.v4.app.*;
import android.support.v4.content.*;
import android.support.v7.app.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import android.app.*;
import com.learn.app.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.SharedPreferences;
import android.support.v4.view.*;
import com.learn.app.tab.*;
import android.support.design.widget.*;
import com.learn.app.ENDownloadView;
import com.learn.app.bottleload.BottleLoadingView;
import com.youth.banner.loader.*;
import java.util.*;
import com.youth.banner.*;
import com.bumptech.glide.*;
import com.android.permission.*;
public class Beautiful extends AppCompatActivity
{
	private Banner mBanner;
	private List<String> imageArray;
    private List<String> imageTitle;
	ENDownloadView loadingView;
	public static  SharedPreferences sp;
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		sp = getSharedPreferences("config",Context. MODE_PRIVATE);    
        String selectcolor = sp.getString("color", ""); 
		//姨妈红
        if(selectcolor.equals("-769226")){
            setTheme(R.style.RedTheme);   
        }
        //原谅绿
        else if (selectcolor.equals("-11751600")){
            setTheme(R.style.GreenTheme);
        }
        //天空蓝
        else if(selectcolor.equals("-14575885")){
            setTheme(R.style.BlueTheme);
        }
        //卡其褐
        else if(selectcolor.equals("-8825528")){
            setTheme(R.style.BrowmTheme);
        }
        //太空灰
        else if(selectcolor.equals("-6381922")){
            setTheme(R.style.GreyTheme);
        }
        //哔哩粉
        else if(selectcolor.equals("-1499549")){
            setTheme(R.style.PinkTheme);
        }
        //基佬紫
        else if(selectcolor.equals("-6543440")){
            setTheme(R.style.PurpleTheme);
        }
        //橘子橙
        else if(selectcolor.equals("-26624")){
            setTheme(R.style.OrangeTheme);
        }
        //水鸭青
        else if(selectcolor.equals("-16738680")){
            setTheme(R.style.TealTheme);
        }
		super.onCreate ( savedInstanceState );

		setContentView ( R.layout.beautiful);
		
		Toolbar toolBar= (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolBar);
		setActionBar();
		loadingView = (ENDownloadView) findViewById(R.id.view_loading);
		loadingView.show();
//设置图片加载集合
        imageArray=new ArrayList<>();
		imageArray.add("http://img02.sogoucdn.com/app/a/100520146/75e6271c25193d91bfd36c8566cbbda7");
        imageArray.add("http://img03.sogoucdn.com/app/a/100520146/3914369c1eb3891eda7f615a97cb7cfd");
        imageArray.add("http://img02.sogoucdn.com/app/a/100520146/3fca75c608cceea85529e7e2e5e23a8f");
        //设置图片标题集合
        imageTitle=new ArrayList<>();
        imageTitle.add("aaaaaaaaa");
        imageTitle.add("bbbbbbbbb");
        imageTitle.add("ccccccccc");

        mBanner = (Banner)findViewById(R.id.banner);
        //设置banner样式
        mBanner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
        //设置图片加载器
        mBanner.setImageLoader(new GlideImageLoader());
        //设置图片集合
        mBanner.setImages(imageArray);
        //设置banner动画效果
        mBanner.setBannerAnimation(Transformer.Default);
        //设置标题集合（当banner样式有显示title时）
        mBanner.setBannerTitles(imageTitle);
        //设置轮播时间
        mBanner.setDelayTime(2000);
        //设置指示器位置（当banner模式中有指示器时）
        mBanner.setIndicatorGravity(BannerConfig.RIGHT);
        //banner设置方法全部调用完毕时最后调用
        mBanner.start();
    }
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.beautiful, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
		if(id==android.R.id.home){
			onBackPressed();
		}
		if (id == R.id.beautiful1){
			Intent intent=new Intent(Beautiful.this,HeartActivity.class);
			startActivity(intent,
						  ActivityOptions
						  .makeSceneTransitionAnimation(this).toBundle());
						  return true;
		}

		if(id==R.id.beautiful2){
			
		}
		if(id==R.id.theme1){

			return true;
		}
		if(id==R.id.theme2){

		}
		
		return super.onOptionsItemSelected(item);
    }


	@Override
    protected void onResume() {
        super.onResume();
        ((BottleLoadingView) findViewById(R.id.bottle_view_small)).performAnimation();
    }
	private void setActionBar() {
        setTitle(getResources().getString(R.string.hj));
        try {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
	private class GlideImageLoader extends ImageLoader {

        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
            //Glide 加载图片简单用法
            Glide.with(context).load((String) path).into(imageView);
        }

    }
    public void setBanner(List<String> imgUrls) {
        mBanner.setImages(imgUrls).setImageLoader(new GlideImageLoader()).start();
    }
	@Override
    public void onBackPressed() {
        super.onBackPressed();
        // 添加返回过渡动画.
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    }
}

